numbers=[1,2,3,4,5,6,4,3,5]
mixeddata=[1,"hello",False,5.3]
nested=[[1,2],[3,4]]
numbers.append(9)
print(numbers)
numbers.insert(4,6)
print(numbers)
numbers.remove(5)
print(numbers)
numbers.pop()
print(numbers)
numbers.pop(5)
print(numbers)
numbers.reverse()
print(numbers)
numbers.sort()
print(numbers)
print(numbers.count(3))
print(numbers.index(5))
numbers.clear()
print(numbers)


my_list=['a','p','p','l','e']
print(my_list[2:4])
print(my_list[3:])
print(my_list[:])
print(my_list[:3])


#adding one list to another list
numbers=[1,3,5]
even_numbers = [2,4,6]
numbers.extend(even_numbers)
print(numbers)


