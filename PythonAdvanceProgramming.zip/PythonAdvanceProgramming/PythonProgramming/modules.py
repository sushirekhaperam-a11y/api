import math

print(math.sqrt(9))
print(math.pi)

from datetime import datetime
print(datetime.now())

from datetime import date
print(date.today())
