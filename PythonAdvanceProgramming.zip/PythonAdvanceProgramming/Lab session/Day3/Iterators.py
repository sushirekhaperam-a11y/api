#Create a custom iterator that prints numbers from 1 to 5.
a   =[1,2,3,4,5]
iterator = iter(a)
print(next(iterator))
print(next(iterator))
print(next(iterator))
print(next(iterator))
print(next(iterator))
#Write an iterator class that returns next even number.
print(next(iterator))
#Explain and demonstrate the use of __iter__() and __next__()
